package com.example.tp4;

import static android.net.Uri.parse;
import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.tp4.R;
import com.example.tp4.databinding.ActivityMainBinding;

import java.util.zip.Inflater;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private ActivityMainBinding ui;
    //private int compteur =0;
    TextView texte = findViewById(R.id.texte);
    TP4Application app = (TP4Application) getApplicationContext();
    int compteur = app.getCompteur();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        Intent intent = getIntent();
        String username = intent.getStringExtra("username");
        texte.setText("Bonjour "+username);
        Button bouton2 = findViewById(R.id.bouton2);
        ui = ActivityMainBinding.inflate(getLayoutInflater());
        /*ui.bouton2.setOnClickListener(btn -> {
            compteur += 2;
            ui.texte.setText("compteur ="+compteur);
        });*/
        ui.bouton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                compteur +=5;
                ui.texte.setText("compteur ="+compteur);
            }
        });

        ui.bouton3.setOnClickListener(this::onBouton3Click);
        setContentView(ui.getRoot());
        setTitle(getLocalClassName());
        Log.i(TAG, "dans " + getLocalClassName() + ".onCreate");
        TextView textview = findViewById(R.id.texte);
        textview.setText("Bonjour");

        Button bouton4 = findViewById(R.id.bouton4);
        ui.bouton4.setOnClickListener(this);

        Button bouton5 = findViewById(R.id.bouton5);
        ui.bouton5.setOnClickListener(this::onBouton5Click);

        Button bouton6 = findViewById(R.id.bouton6);
        ui.bouton6.setOnClickListener(this::onBouton6Click);

        Button bouton7 = findViewById(R.id.bouton7);
        ui.bouton7.setOnClickListener(this::onBouton7Click);
    }

    private void onBouton3Click(View view) {
        compteur *= 2;
        ui.texte.setText("compteur ="+compteur);
    }
    private void onBouton5Click(View view) {
        Intent intent = new Intent(this, InfosActivity.class);
        startActivity(intent);
    }
    private void onBouton6Click(View view) {
        Intent intent = new Intent(this, InfosActivity.class);
        startActivity(intent);

    }

    private void onBouton7Click(View view) {
        String url="https: //perso.univ-rennes1.fr/pierre.nerzic/Android";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        setTitle(getLocalClassName());
        Log.i(TAG, "dans " + getLocalClassName() + ".onResume");
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        setTitle(getLocalClassName());
        Log.i(TAG, "dans " + getLocalClassName() + ".onDestroy");
    }

    @Override
    protected void onPause() {
        super.onPause();
        setTitle(getLocalClassName());
        Log.i(TAG, "dans " + getLocalClassName() + ".onPause");
    }

    @Override
    public void onClick(View v) {

    }
}


