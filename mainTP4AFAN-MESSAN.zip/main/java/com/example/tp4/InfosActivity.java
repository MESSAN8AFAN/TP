package com.example.tp4;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.tp4.databinding.ActivityMainBinding;

public class InfosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_infos);
        ActivityMainBinding ui = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(ui.getRoot());
        setTitle(getLocalClassName());
    }
}
